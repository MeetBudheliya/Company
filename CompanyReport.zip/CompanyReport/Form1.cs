﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyReport
{
    public partial class Form1 : Form
    {

        CompanyDBEntities DBObject = new CompanyDBEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            show_data();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void add_department_button_Click(object sender, EventArgs e)
        {
            Department department = new Department();
            department.department_name = add_department_tb.Text;

            DBObject.Departments.Add(department);
            DBObject.SaveChanges();

            show_data();
        }

        private void show_data()
        {
            dataGridView1.DataSource = DBObject.Departments.ToList();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

    }
}
